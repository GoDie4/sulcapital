
export default function page() {
  return (
    <>
      {/* <BannerInternas
        image="/images/fondos/fondo_vista.webp"
        title="Desde S/ 400 casa en Satipo"
      />
      <GaleriaInmuebles />
      <section>
        <ContentMain className="w-full flex flex-col lg:flex-row gap-8 pb-10">
          <div className="w-full lg:w-2/3 space-y-6">
            <DescripcionInmueble />
            <VideoInmueble />
            <UbicacionInmueble />
          </div>
          <div className="w-full lg:w-1/3 space-y-12 ">
            <FormContactoInmueble />
            <OtrosInmueblesUsuario />
          </div>
        </ContentMain>
        <ContentMain className="pb-20">
          <p className="text-xl font-TypographBold text-secondary-main mb-6">
            Inmuebles relacionados
          </p>
            <ContenteInmuebles/>
        </ContentMain>
      </section> */}
    </>
  );
}
