import React from "react";

export const VistaRapidaInmueble = () => {
  return (
    <div className="w-full space-y-5 a">
      {/* <GaleriaInmuebles />
      <DescripcionInmueble /> */}
    </div>
  );
};
