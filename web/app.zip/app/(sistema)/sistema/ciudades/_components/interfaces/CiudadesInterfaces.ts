export interface Ciudad {
  nombre: string;
  descripcion: string;
  coordenadas: string;
}

export interface CiudadList {
  id: string;
  nombre: string;
  descripcion: string;
  coordenadas: string;
  imagen: string
}
