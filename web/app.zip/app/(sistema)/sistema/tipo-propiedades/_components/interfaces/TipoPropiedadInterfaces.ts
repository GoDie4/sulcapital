export interface AddTipoPropiedad {
  nombre: string;
}
